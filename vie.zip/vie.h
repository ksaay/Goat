#ifndef VIE_H_INCLUDED
#define VIE_H_INCLUDED 
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
typedef struct vie 
{
SDL_Rect position ;  
int val ;
SDL_Surface *image[6]; 
} vie ; 

void init_vie(vie *v) ; 
void updatevie(vie *v,int test) ;  
void setup(vie v ,SDL_Surface *ecran);
void displayvie(vie v ,SDL_Surface *ecran) ;  
void vie_freevie(vie *v ) ;  

#endif
