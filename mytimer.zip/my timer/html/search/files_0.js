var searchData=
[
  ['score_2ec',['score.c',['../score_8c.html',1,'']]]
];
