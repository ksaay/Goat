var searchData=
[
  ['score',['score',['../structscore.html',1,'']]],
  ['score_2ec',['score.c',['../score_8c.html',1,'']]],
  ['setup',['setup',['../score_8c.html#aa9650948b82ecd2181f466e0a4955a3a',1,'score.c']]]
];
