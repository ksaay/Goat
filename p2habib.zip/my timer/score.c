/**
*
@author habib hadroug
@brief tmer
@date avril 28 2020
@version 1.0
@file score.c
*/
#include "score.h"
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "SDL/SDL_ttf.h"
/**
*
@brief pour intialiser
@param temp
@param ecran
@return rien
*/
void setup(score *s,SDL_Surface *ecran)
{
  //SDL_FillRect(ecran,NULL,SDL_MapRGB(ecran->format,255,255,255));
    char time[50];
  (s->x_minutes)=0;
  (s->x_seconds)=0;
  (s->x_milliseconds)=0;
  //sprintf(time,"%02d:%02d ",(s->x_minutes),(s->x_seconds));
  (s->position.x)=1200;
  (s->position.y)=0;
  (s->police)=TTF_OpenFont("pacifico.ttf",65);
  SDL_Color color={100,100,100};
  //(s->texte)=TTF_RenderText_Blended((s->police),time,color);
  SDL_WM_SetCaption("score", NULL);
  (s->x_startTime)=clock();
}
/**
*
@brief pour compter
@param temp
@param ecran
@return rien
*/
void timer(score *s,SDL_Surface *ecran)
{
  char time[50];
  SDL_Color color={100,100,100};

	if((s->x_minutes!=3))
            {

		(s->x_countTime)=clock(); // update timer difference
		(s->x_milliseconds)=(s->x_countTime)-(s->x_startTime);
		(s->x_seconds)=((s->x_milliseconds)/(CLOCKS_PER_SEC))-((s->x_minutes)*60);
		(s->x_minutes)=((s->x_milliseconds)/(CLOCKS_PER_SEC))/60;
   sprintf(time,"%02d:%02d ",(s->x_minutes),(s->x_seconds));
    (s->texte)=TTF_RenderText_Blended((s->police),time,color);
    SDL_BlitSurface((s->texte),NULL,ecran,&(s->position));
    SDL_Flip(ecran);
            }

}
/**
*
@brief pour liberer la memoire
@param temp
@return rien
*/
void freescore(score *s)
{
 TTF_CloseFont(s->police);
 SDL_FreeSurface(s->texte);
}
