#ifndef SCORE_H_INCLUDED
#define SCORE_H_INCLUDED 
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "SDL/SDL_ttf.h"
/**
*
@struct temps
@brief structure du temps
*/
typedef struct  
{
clock_t x_startTime;
clock_t x_countTime;
unsigned int x_minutes;
unsigned int x_seconds;
unsigned int x_milliseconds;
SDL_Rect position ;  
SDL_Surface *texte;
TTF_Font *police;
}score; 

void setup(score *s,SDL_Surface *ecran);
void timer(score *s,SDL_Surface *ecran);
void freescore(score *s);  

#endif
