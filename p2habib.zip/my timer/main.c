#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "SDL/SDL_ttf.h"
#include"score.h"
#define WIDTH 1400
#define HEIGHT 600


int main ( int argc, char* argv[])
{
        SDL_Surface *ecran = NULL;
        SDL_Event event;
        int gameover = 1;
	score s;
        SDL_Init(SDL_INIT_EVERYTHING);
        ecran = SDL_SetVideoMode(WIDTH, HEIGHT, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
        TTF_Init();
        setup(&s,ecran);
        while(gameover)
        { 
         
	  SDL_Event event ;
       while(SDL_PollEvent(&event))
		{

			if(event.type==SDL_QUIT || (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE)){
				gameover = 0;
			}

		} 
			SDL_FillRect(ecran,NULL,0x000000);
         timer(&s,ecran);
            //SDL_Flip(ecran);
        }
	freescore(&s);
        TTF_Quit();
        SDL_Quit();
        return 0;
}
