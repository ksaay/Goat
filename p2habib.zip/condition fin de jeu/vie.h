#ifndef VIE_H_INCLUDED
#define VIE_H_INCLUDED 
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include"time.h"
/**
*
@struct vie
@brief structure du vie
*/
typedef struct vie 
{
Uint32 m;
SDL_Rect position ;  
int val ;
SDL_Surface *image[6]; 
} vie ; 

void init_vie(vie *v) ; 
void updatevie(vie *v,int test) ;  
void setupv(vie v ,SDL_Surface *ecran);
void displayvie(vie v ,SDL_Surface *ecran) ;  
void vie_freevie(vie *v ) ;  
     int time_game(int time_spent);
int fin_jeu(int enigme1,int enigme2,vie *v,int timer);       
#endif
