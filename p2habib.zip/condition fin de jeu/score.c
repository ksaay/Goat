/**
*
@author habib hadroug
@brief tmer
@date avril 28 2020
@version 1.0
@file score.c
*/
#include "score.h"
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "SDL/SDL_ttf.h"
/**
*
@brief pour intialiser
@param score
@param ecran
@return rien
*/
void setup(score *s,SDL_Surface *ecran)
{
  char result[50];
  sprintf(result,"%d",(s->val));
  (s->position.x)=1200;
  (s->position.y)=0;
  (s->police)=TTF_OpenFont("pacifico.ttf",65);
  SDL_Color color={0,0,100};
  (s->texte)=TTF_RenderText_Blended((s->police),result,color);
  SDL_WM_SetCaption("score", NULL);
  SDL_FillRect(ecran,NULL,SDL_MapRGB(ecran->format,255,255,255));
  SDL_BlitSurface((s->texte),NULL,ecran,&(s->position));
  SDL_Flip(ecran);
  (s->val)+=10;
}
/**
*
@brief pour liberer
@param score
@return rien
*/
void freescore(score *s)
{
 TTF_CloseFont(s->police);
 SDL_FreeSurface(s->texte);
}
