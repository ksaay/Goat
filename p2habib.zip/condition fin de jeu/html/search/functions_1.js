var searchData=
[
  ['setup',['setup',['../score_8c.html#aa9650948b82ecd2181f466e0a4955a3a',1,'score.c']]]
];
