#pragma once
#include<SDL/SDL.h>
#include<SDL/SDL_ttf.h>

/**
*
@struct temps
@brief structure du temps
*/
typedef struct Time {
	SDL_Surface *msg;
	TTF_Font *font;
	int time;
	char timeString[10];
} Time;

void initializerTemps(Time *time);
int afficherTemps(Time *time,SDL_Surface **ecran);
