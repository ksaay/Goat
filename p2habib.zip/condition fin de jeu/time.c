/**
*
@author habib hadroug
@brief tmer
@date avril 28 2020
@version 1.0
@file score.c
*/
#include <stdio.h>
#include"time.h"
/**
*
@brief pour intialiser
@param time
@return rien
*/
void initializerTemps(Time *time){
	time->font = TTF_OpenFont("font.ttf", 32);
	time->time = 0;
	sprintf(time->timeString,"00:00");
	SDL_Color color = {0,255,44};
	time->msg = TTF_RenderText_Solid(time->font,time->timeString,color);
}
/**
*
@brief pour afficher
@param ecran
@return entier
*/
int afficherTemps(Time *time, SDL_Surface **ecran){
int a=0;
	SDL_Color color = {0,255,44};
	time->time++;
       // printf("%d \n",time->time);
	if(time->time % 60 == 0){
		sprintf(time->timeString,"%02d:%02d\n",time->time/60/60,(time->time/60)%60);
		time->msg = TTF_RenderText_Solid(time->font,time->timeString,color);
	}
if(time->time>3000)
a=1;
	//SDL_BlitSurface(time->msg,NULL,*ecran,NULL); 
  // SDL_Flip(*ecran);
return a;
}
