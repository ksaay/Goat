#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include"time.h"
#include "SDL/SDL_ttf.h"
#include"score.h"
#include"vie.h"
#define WIDTH 1400
#define HEIGHT 600


int main ( int argc, char* argv[])
{ 

int timer,enigme1=1,enigme2=1;
        SDL_Surface *ecran = NULL;
        SDL_Event event;
        int gameover = 1;
        int test;
	score s;
        	vie v;
        SDL_Color color={0,0,0};
        s.val=0;
	SDL_Init(SDL_INIT_EVERYTHING);
TTF_Init();
	
	Time time;
	initializerTemps(&time);
        ecran = SDL_SetVideoMode(WIDTH, HEIGHT, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
init_vie(&v);
        v.val=5;
        TTF_Init();
        setup(&s,ecran);
        setupv( v ,ecran);
        //SDL_EnableKeyRepeat(10,10);
        while(gameover)
        {
 if(fin_jeu( enigme1,enigme2,&v,timer) ==1)
{
if(v.val>0)
v.val--;
}
printf("fin %d \n",fin_jeu( enigme1,enigme2,&v,timer));
                                 displayvie(v ,ecran);
       
	  SDL_Event event ;
          SDL_PollEvent(&event);
         switch(event.type)
        {
                       
                        case SDL_QUIT:
                                gameover = 0;
                                break;
                        case SDL_KEYDOWN:
                                 setup(&s,ecran);
                              if(v.val!=0)
				 v.val--;
                                 displayvie(v ,ecran);
                                 break;                              
          }
			timer=afficherTemps(&time,&ecran);
			SDL_Flip(ecran);
        }
	vie_freevie(&v);
	freescore(&s);
        TTF_Quit();
        SDL_Quit();
        return 0;
}
