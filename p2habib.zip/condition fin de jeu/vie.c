/**
*
@author habib hadroug
@brief tmer
@date avril 28 2020
@version 1.0
@file score.c
*/
#include "vie.h"
#include "time.h"
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
/**
*
@brief pour intialiser
@param vie
@param ecran
@return rien
*/
void init_vie(vie *v) 
{
 (v->position.x)=0;
 (v->position.y)=0;
 (v->val)=5 ;
 (v->image[0])=IMG_Load("8.jpg") ;
 (v->image[1])=IMG_Load("vie1.png") ;
 (v->image[2])=IMG_Load("vie2.png") ;
 (v->image[3])=IMG_Load("vie3.png") ;
 (v->image[4])=IMG_Load("vie4.png") ;
 (v->image[5])=IMG_Load("vie5.png") ;
}
/**
*
@brief pour setup
@param vie
@param ecran
@return rien
*/
void setupv(vie v ,SDL_Surface *ecran)
{
  SDL_WM_SetCaption("vie", NULL);
  SDL_FillRect(ecran,NULL,SDL_MapRGB(ecran->format,255,255,255)) ;
  SDL_BlitSurface(v.image[(v.val)],NULL,ecran,&(v.position));
  SDL_Flip(ecran) ;

}
/**
*
@brief pour afficher vie
@param vie
@param ecran
@return rien
*/

void displayvie(vie v ,SDL_Surface *ecran) 
{
  //SDL_FillRect(ecran,NULL,SDL_MapRGB(ecran->format,255,255,255)) ;
  SDL_BlitSurface(v.image[(v.val)],NULL,ecran,&(v.position));
  SDL_Flip(ecran);
}
/*void lose_vie(vie *v)
{
Uint32 end= SDL_GetTicks();
if(end - v-> m >2000  ||  v->m == 0)
 {
if (v->val!=0)
v->val--;
v->m = end;
 }
}*/

/**
*
@brief pour liberer
@param vie
@return rien
*/
void vie_freevie(vie *v ) 
{
SDL_FreeSurface(v->image[0]);
SDL_FreeSurface(v->image[1]);
SDL_FreeSurface(v->image[2]);
SDL_FreeSurface(v->image[3]);
SDL_FreeSurface(v->image[4]);
SDL_FreeSurface(v->image[5]);
}
/**
*
@brief pour fin de jeu
@param enigme1
@param enigme2
@param vie
@param timer
@return entier
*/    
int fin_jeu(int enigme1,int enigme2,vie *v,int timer)        
{
int a=0;
  if(enigme1==0)
     a=1;
  if(enigme2==0)
     a=1;
   /*if (time_game(time_spent)==1)
     a=1;*/
    if (timer==1)
      a=1;
//printf("%d \n",timer);
return a;
}  
        

			
			
