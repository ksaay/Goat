
#include<SDL/SDL_ttf.h>
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <time.h>

#define w 1360
#define h 560

#define mapw 6838 
#define maph 613

#define xwood 300
#define ywood 360

#define xboat 50
#define yboat 400

#define xd 100
#define yd 360

#define wd 72
#define hd 144

#define xb 2293
#define yb 316

#define wb 559
#define hb 128
typedef struct 
{
  int x ;
  int y ;
  float rayon ;

}Circle;

typedef struct 
{
  SDL_Surface *img ;
  SDL_Rect pos;
  int w1;
  int h1;
  Circle c ;
  
}Objet;



typedef struct
{
 SDL_Rect posd;
 SDL_Rect posm;
 int vie;
 int score;
}savef;


typedef struct vie 
{
SDL_Rect position ;  
int val ;
SDL_Surface *image[6]; 
} vie ;





typedef struct Time {
	SDL_Surface *msg;
	TTF_Font *font;
	int time;
	char timeString[10];
} Time;

 


int starts(SDL_Surface *screen,Objet *start);
void initialiser (Objet *map ,Objet *d,Objet *wood ,Objet *boat );
void setup (SDL_Surface *screen, Objet *map , Objet *d);
void affichage_objet (SDL_Surface *screen ,Objet *boat ,Objet *wood,Objet *map);
void scrolling_droit (SDL_Surface *screen , Objet *map, Objet *d);
void scrolling_gauche (SDL_Surface*screen , Objet *map, Objet *d);
//void deplacement_objet( Objet *map,SDL_Surface *screen ,Objet *d,int *running,int *test,Objet *start)
void evenement (SDL_Surface *screen ,Objet *map,int *running , Objet *d,int test,Objet *boat ,Objet *wood,vie *v);
void save( Objet *map, Objet *d,vie *v,Objet *boat);
void read( Objet *map, Objet *d,vie *v,Objet *boat);
void free_memory (Objet *map, Objet *d,Objet *boat ,Objet *wood,Objet *start,Objet *end);
void choix(int *a);
void ends(SDL_Surface *screen,Objet *end);


void init (Objet *objet1,Objet *objet2) ;
void setup (SDL_Surface *screen,Objet *objet1,Objet *objet2) ;
void calculer_centre_rayon (Objet *objet1,Objet *objet2) ;
float calculer_distance (Objet *objet1,Objet *objet2) ;
int verif_collision ( Objet *objet1,Objet *objet2,float D1 ) ;
//void deplacement_objet(Objet *objet,int *running) ;
void update (SDL_Surface *screen,Objet *objet1,Objet *objet2) ;
void liberate_memory (Objet *objet1,Objet *objet2) ;


void init_vie(vie *v) ; 
void updatevie(vie *v,int test) ;  
void setupvie(vie v ,SDL_Surface *screen);
void displayvie(vie v ,SDL_Surface *screen) ;  
void vie_freevie(vie *v ) ; 



