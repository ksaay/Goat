/**
*
@author habib hadroug
@brief tmer
@date avril 28 2020
@version 1.0
@file score.c
*/
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include"time.h"
#include<SDL/SDL_ttf.h>
#include <SDL/SDL_image.h>
#include <time.h>
#include "scrolling.h"
/**
*
@brief pour intialiser
@param start
@param ecran
@return rien
*/
int starts(SDL_Surface *screen,Objet *start)
{
int a;
	start->img=IMG_Load("start.png");
	start->pos.x=0;
	start->pos.y=0;
	SDL_BlitSurface(start->img,NULL, screen, &(start->pos)) ;
	SDL_Flip(screen) ;

}
/**
*
@brief pour intialiser
@param map
@param d
@param wood
@param boat
@return rien
*/
void initialiser (Objet *map ,Objet *d,Objet *wood ,Objet *boat ) 
{
	SDL_WM_SetCaption("scrolling", NULL);

	map->img=IMG_Load("mapp.png") ;
	map->pos.x=0 ;
	map->pos.y=0 ;

	d->img=IMG_Load("detective.png") ;
	d->pos.x=xd ;
	d->pos.y=yd ;
	d->w1=wd;
	d->h1=hd;
	SDL_SetColorKey(d->img,SDL_SRCCOLORKEY,SDL_MapRGB(d->img->format,255,255,255));

        wood->img=IMG_Load("wood.png") ;
        wood->pos.x=2000 ;
        wood->pos.y=ywood ;

        boat->img=IMG_Load("boatt.png") ;
        boat->pos.x=2000 ;
        boat->pos.y=yboat ;
}
void setup (SDL_Surface *screen, Objet *map , Objet *d)
{
	SDL_BlitSurface(map->img,NULL,screen, &(map->pos));
	SDL_BlitSurface(d->img,NULL, screen, &(d->pos)) ;
	SDL_Flip(screen) ;
}
void affichage_objet (SDL_Surface *screen ,Objet *boat ,Objet *wood,Objet *map)
{
      if((map->pos.x>600)&&(map->pos.x<2100))
                     {
                        SDL_BlitSurface(wood->img,NULL, screen, &(wood->pos)) ;
                       // SDL_BlitSurface(boat->img,NULL, screen, &(boat->pos)) ;
                     }
}

void scrolling_droit (SDL_Surface *screen , Objet *map, Objet *d)
{
	if (map->pos.x<=mapw)
	{
		map->pos.x+=20 ; 
	}
	SDL_BlitSurface(map->img,&(map->pos),screen, NULL);
}
void scrolling_gauche (SDL_Surface*screen , Objet *map, Objet *d) 
{
	if (map->pos.x>=0)
	{
		map->pos.x-=20 ;
	}
	SDL_BlitSurface(map->img,&(map->pos),screen, NULL);  
}
 void deplacement_objet( Objet *map,SDL_Surface *screen ,Objet *d,int *running,int       *test,Objet *start)
{
int a;

	SDL_Event event1 ;

	SDL_WaitEvent(&event1);
	switch(event1.type)
	{
		case SDL_QUIT:
		*running=0;
		break;
		case SDL_KEYDOWN:
		switch(event1.key.keysym.sym)
		{
                  /*      case SDLK_y:
                        save(map,d);
                        *running = 0;
                        break;
                        case SDLK_n:
                        setup (screen,map ,d);
                        break;
                        case SDLK_l:
                          if((a!=1)&&(d->pos.x==xd))
                     {

                     	read(map,d);
                     	a=1;
                     }
                     setup (screen,map ,d);
                        break;*/
			case SDLK_DOWN:
			d->pos.y+=5;
			SDL_BlitSurface(map->img,&(map->pos),screen, NULL);
			SDL_BlitSurface(d->img,NULL, screen, &(d->pos)) ;
			//SDL_Flip(screen) ;
			break;
			case SDLK_UP:
			d->pos.y-=5;
			SDL_BlitSurface(map->img,&(map->pos),screen, NULL);
			SDL_BlitSurface(d->img,NULL, screen, &(d->pos)) ;
			//SDL_Flip(screen) ;
			break;
			case SDLK_RIGHT:
			d->pos.x++;
			SDL_BlitSurface(map->img,&(map->pos),screen, NULL);
			SDL_BlitSurface(d->img,NULL, screen, &(d->pos)) ;
			//SDL_Flip(screen) ;
			break;
			case SDLK_LEFT:
			d->pos.x--;
			SDL_BlitSurface(map->img,&(map->pos),screen, NULL);
			SDL_BlitSurface(d->img,NULL, screen, &(d->pos)) ;
			//SDL_Flip(screen) ;
			break;
		}
	}
	if (d->pos.x>200)
	{
		*test=1;
	}
}

void evenement (SDL_Surface *screen ,Objet *map,int *running , Objet *d,int test,Objet *boat ,Objet *wood,vie *v)
{
                      
	int a,test1;
	SDL_Event event;
        SDL_PollEvent(&event);
	switch(event.type)
	{
		case SDL_QUIT:
		*running = 0;
		break;
		case SDL_KEYDOWN:

		switch(event.key.keysym.sym)

		{
			case SDLK_DOWN: //fleche bas
                        if(d->pos.y<350)
                        {
			d->pos.y+=5;
                        }
            
			SDL_BlitSurface(map->img,&(map->pos),screen, NULL);
			SDL_BlitSurface(d->img,NULL, screen, &(d->pos)) ;
                        affichage_objet (screen,boat,wood,map)  ;
                        //SDL_Flip(screen) ;

			break;

			case SDLK_UP:  //fleche haut
                        if(d->pos.y>250)
                        {
			d->pos.y-=5;
                        }
			SDL_BlitSurface(map->img,&(map->pos),screen, NULL);
			SDL_BlitSurface(d->img,NULL, screen, &(d->pos)) ;
                        affichage_objet (screen,boat,wood,map)  ;
                        //SDL_Flip(screen) ;
			break;

                     case SDLK_RIGHT: // Flèche droite 
                     //if(test1==1)
                    // {
                        wood->pos.x-=20;
                     	scrolling_droit (screen ,map,d) ;
                     	SDL_BlitSurface(d->img,NULL, screen, &(d->pos)) ;

			d->pos.x++;
			SDL_BlitSurface(map->img,&(map->pos),screen, NULL);
			SDL_BlitSurface(d->img,NULL, screen, &(d->pos)) ;

                         affichage_objet (screen,boat,wood,map)  ;
                         //SDL_Flip(screen) ;
                     //}
                     break;

                     case SDLK_LEFT: // Flèche gauche
                     //if(test1==1)
                    // {
                         scrolling_gauche (screen ,map,d) ;
                        
                        wood->pos.x+=20;
                     	SDL_BlitSurface(d->img,NULL, screen, &(d->pos)) ;

			d->pos.x--;
			SDL_BlitSurface(map->img,&(map->pos),screen, NULL);
			SDL_BlitSurface(d->img,NULL, screen, &(d->pos)) ;

                        affichage_objet (screen,boat,wood,map)  ;
                        //SDL_Flip(screen) ;
                     //}
                     break;

                     case SDLK_l:
                     if((a!=1)&&(d->pos.x==xd))
                     {

                     	read(map,d,v,boat);
                     	a=1;
                     }
                     //setup (screen,map ,d);
                     break;

                     case SDLK_ESCAPE:
                          if((v->val)>0)
                     		save(map,d,v,boat);
                     		*running = 0;

                     break;

                 }

                 break;    
             }

         if (d->pos.x>200)
	{
		test=1;
	}

         }

         void save( Objet *map, Objet *d,vie *v,Objet *boat)
         {
         	FILE *f=NULL;
         	f=fopen("savefile","w");
         	if(f!=NULL)
         	{
         		fprintf(f,"%d ; %d ; %d ; %d ; %d ; %d ; %d",map->pos.x,map->pos.y,d->pos.x,d->pos.y,v->val,boat->pos.x,boat->pos.y);
         	}
         	else
         		printf("error \n");
         	fclose(f);
         }
         void read( Objet *map, Objet *d,vie *v,Objet *boat)
         {
         	FILE *f;
         	f=fopen("savefile","r");
         	if(f!=NULL)
         	{
         		fscanf(f,"%hd ; %hd ; %hd ; %hd ; %d ; %hd ; %hd",&map->pos.x,&map->pos.y,&d->pos.x,&d->pos.y,&v->val,&boat->pos.x,&boat->pos.y);
         	}
         	else
         		printf("error \n");
         	fclose(f);
         }

         void free_memory (Objet *map, Objet *d,Objet *boat ,Objet *wood,Objet *start,Objet *end)
         {
                SDL_FreeSurface (boat->img) ;
                SDL_FreeSurface (wood->img) ;
         	SDL_FreeSurface (map->img) ;
         	SDL_FreeSurface (d->img) ;
                SDL_FreeSurface (start->img) ;
                SDL_FreeSurface (end->img) ;
         	SDL_Quit () ;

         }

       void ends(SDL_Surface *screen,Objet *end)
        {
	end->img=IMG_Load("end.png");
	end->pos.x=0;
	end->pos.y=0;
	SDL_BlitSurface(end->img,NULL, screen, &(end->pos)) ;
	SDL_Flip(screen) ;
        }

     

