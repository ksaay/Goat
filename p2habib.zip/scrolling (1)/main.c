#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "scrolling.h"

int main()
{
	
SDL_Surface *screen = NULL ;
Objet map,d,wood,boat,start,end ;
int a,collision,running=1 ,test,c=9900;
float D ;
vie v;
  screen= SDL_SetVideoMode(w, h, 32, SDL_HWSURFACE|SDL_DOUBLEBUF);

  initialiser (&map ,&d,&wood,&boat ) ;

  starts(screen,&start);
  init_vie(&v);
  v.val=5;

  setupvie( v ,screen);
  
  SDL_EnableKeyRepeat(10, 10);



  while(running){
          SDL_Flip(screen);
      evenement (screen,&map,&running,&d,test,&wood,&boat,&v) ;
      displayvie(v ,screen);
      calculer_centre_rayon (&d,&boat) ;
      D=calculer_distance (&d,&boat) ;
      collision=verif_collision (&d,&boat,D ) ;

   if(collision)
     {

       if(v.val!=0)
        {  
	 a=1;
        }
     }
   
    if((!collision)&&(a==1))
     {
      v.val--;
      a=0;
     }
     SDL_Flip(screen);
     }

    free_memory (&map,&d,&boat,&wood,&start,&end) ;
    vie_freevie(&v);
            TTF_Quit();
    return EXIT_SUCCESS;
}
