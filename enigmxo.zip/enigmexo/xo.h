
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_image.h>
#include <time.h>


/// Les prototypes :
void initialiserEcran();
void initialiserMatrice();
void choisirXO();
void jouer();
void jouerJoueur();
void afficherEcran();
void ecranblanc();
void jouerOrdinateur();
void pause();






