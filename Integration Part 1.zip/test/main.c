#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include "perso.h"
#include "enemi.h"
#include "scrolling.h"
#include "score.h"
#include "vie.h"
#include "deplacement.h"
#include "collision.h"
#include "enigme.h"
#include "time.h"
int main()
{
char pause;
int test_scrolling;
int a,b;
int dep1=400;
int dep2=520;
a=0;b=1;
SDL_EnableKeyRepeat(10, 10);
int game=1;
score s; s.val=0;
vie v; v.val=5;
SDL_Event event;
Time time;
perso p;
enemi e;
Objet map;
SDL_Surface *screen=NULL;
SDL_Init(SDL_INIT_VIDEO);
screen = SDL_SetVideoMode(w,h, 32, SDL_HWSURFACE|SDL_DOUBLEBUF);
printf(" h= %d w = %d",h,w);
SDL_WM_SetCaption("Corona", NULL);
SDL_FillRect(screen,0,SDL_MapRGB(screen->format,0,0,0));
TTF_Init();
init_perso(&p);
init_enemi(&e);
init_vie(&v);
initialiser_map(&map,&p,screen);
initializerTemps(&time);
charger_sprite(&p);
charger_enemi(&e);
setup_scroling_map(screen,&map);

affiche_perso(&p,screen);
affiche_enemi(&e,screen);

setup_score(&s,screen);
setup_vie(v,screen);
displayvie(v,screen);
SDL_Flip(screen);
int enigme_result;
int enigme = 0;
while(game==1)
{
SDL_PollEvent(&event);

if (p.posjoueur.x == 200 && enigme == 0)
{
enigme = 1;
enigme_result=puzzle();
screen = SDL_SetVideoMode(w,h, 32, SDL_HWSURFACE|SDL_DOUBLEBUF);
printf("%d",enigme_result);
if(enigme_result == 1)
addscore(&s,screen);
}
gestion_evenement(event,&p,screen,&game);
evenement(event,screen,&map,&p,&e,&dep1,&dep2);
deplacement_enemy(&e,&a,&b,dep1,dep2);
affiche_perso(&p,screen);
setup_score1(&s,screen);
if(verif_collision(&p,&e)==0)
lose_vie(&v,&p);
displayvie(v,screen);
if (dep1>0)
{
affiche_enemi(&e,screen);
}
afficherTemps(&time,&screen);
SDL_Flip(screen);

}
freescore(&s);
vie_freevie(&v);
SDL_Quit();
return 0;
}


