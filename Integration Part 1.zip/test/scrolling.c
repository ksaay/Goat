#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "scrolling.h"

void initialiser_map (Objet *map,perso *p,SDL_Surface *screen) 
{
  map->img=IMG_Load("map.png") ;
  map->pos.x=0 ;
  map->pos.y=0 ;

 // SDL_SetColorKey(p->sprite,SDL_SRCCOLORKEY,SDL_MapRGB(screen->format,0x00,0x00,0x00));
}
void setup_scroling_map (SDL_Surface *screen,Objet *map)
{
  SDL_BlitSurface(map->img,NULL,screen, &(map->pos));

}

void scrolling_droit (SDL_Surface *screen , Objet *map, perso *d)
{
 if (map->pos.x<=mapw)
  {
   map->pos.x+=20 ; 
  }
   SDL_BlitSurface(map->img,&(map->pos),screen, NULL);
}
void scrolling_gauche (SDL_Surface *screen , Objet *map, perso *d) 
{
 if (map->pos.x>=0)
  {
   map->pos.x-=20 ;
  }
 SDL_BlitSurface(map->img,&(map->pos),screen, NULL);  
}

void evenement (SDL_Event event,SDL_Surface *screen ,Objet *map,perso *d,enemi *e,int *dep1,int *dep2)
{
if(d->posjoueur.x>=20)
{

        switch(event.type)
        {
            
            case SDL_KEYDOWN:

               switch(event.key.keysym.sym)

                  {

                     case SDLK_RIGHT: // Flèche droite 
      	       
                          scrolling_droit (screen ,map,d) ;
                      
                            e->posenemi.x-=20;
(*dep1)-=20;
(*dep2)-=20;

                     break;

                     case SDLK_LEFT: // Flèche gauche

                          scrolling_gauche (screen ,map,d) ;

                        
                           e->posenemi.x+=20;
(*dep1)+=20;
(*dep2)+=20;
                     break;
              

                  }

            break;    
        }
}

SDL_BlitSurface(map->img,&(map->pos),screen, NULL);

}

void free_memory (Objet *map, Objet *d)
{
 SDL_FreeSurface (map->img) ;
 SDL_FreeSurface (d->img) ;
 SDL_Quit () ;

}
