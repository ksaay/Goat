#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "enemi.h"
#include "perso.h"

int verif_collision (perso *p,enemi *e );
