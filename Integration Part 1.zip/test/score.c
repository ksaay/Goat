#include "score.h"
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "SDL/SDL_ttf.h"
void setup_score(score *s,SDL_Surface *ecran)
{
  char result[50];
  sprintf(result,"%d",(s->val));
  (s->position.x)=1150;
  (s->position.y)=0;
  (s->police)=TTF_OpenFont("pacifico.ttf",65);
  SDL_Color color={0,0,100};
  (s->texte)=TTF_RenderText_Blended((s->police),result,color);
  SDL_BlitSurface((s->texte),NULL,ecran,&(s->position));
  //(s->val)+=10;
}
void setup_score1(score *s,SDL_Surface *ecran)
{
  char result[50];
SDL_Color color={0,0,100};
  sprintf(result,"%d",(s->val));
  (s->texte)=TTF_RenderText_Blended((s->police),result,color);
  SDL_BlitSurface((s->texte),NULL,ecran,&(s->position));
  //(s->val)+=10;
}
void addscore(score *s,SDL_Surface *ecran)
{
char result[50];
SDL_Color color={0,0,100};
(s->val)+=10;
  sprintf(result,"%d",(s->val));
  (s->texte)=TTF_RenderText_Blended((s->police),result,color);
  SDL_BlitSurface((s->texte),NULL,ecran,&(s->position));
  

}
void freescore(score *s)
{
 TTF_CloseFont(s->police);
 SDL_FreeSurface(s->texte);
}
