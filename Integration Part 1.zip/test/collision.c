#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "collision.h"
#include "enemi.h"
#include "perso.h"
#define width 1360
#define height 760

#define posXobj1 50 
#define posYobj1 50

#define posXobj2 300
#define posYobj2 80


/*void init (Objet *objet1,Objet *objet2)
{
 objet1->img=IMG_Load("detective.png");
 objet1->pos.x=posXobj1 ;
 objet1->pos.y=posYobj1 ;
 objet1->w=72;
 objet1->h=144;

 objet2->img=IMG_Load("detective.png") ;
 objet2->pos.x=posXobj2 ;
 objet2->pos.y=posYobj2 ;
 objet2->w=72;
 objet2->h=144; 
}*/

/*void setup (SDL_Surface *screen,Objet *objet1,Objet *objet2)
{
 SDL_WM_SetCaption("collision trigo", NULL);
 SDL_FillRect(screen,NULL,SDL_MapRGB(screen->format,255,255,255)) ;
 SDL_BlitSurface(objet1->img,NULL,screen,&(objet1->pos)) ;
 SDL_BlitSurface(objet2->img,NULL,screen,&(objet2->pos)) ;
 SDL_Flip(screen) ;

}
*/
int verif_collision (perso *p,enemi *e )
{
  

  if((p->posjoueur.x+p->posjoueur.h<e->posenemi.x)||(p->posjoueur.x>e->posenemi.x+e->posenemi.w)||(p->posjoueur.y+p->posjoueur.h<e->posenemi.y)||(p->posjoueur.y>e->posenemi.y+e->posenemi.h))
    return 1 ;
  
  return 0 ;
}


