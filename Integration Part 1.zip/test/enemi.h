#ifndef ENEMI_H_INCLUDED 
#define ENEMI_H_INCLUDED

typedef struct
{

SDL_Surface *sprite;
SDL_Rect posanime ;
SDL_Rect posenemi;
int etat;
}enemi;
void init_enemi(enemi *e);
void affiche_enemi(enemi *e,SDL_Surface *screen);
void animate_enemi(enemi *e);
int charger_enemi(enemi *e);






#endif 
