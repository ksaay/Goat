#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "enemi.h"


void deplacement_enemy(enemi *e,int *a,int *b,int dep1,int dep2);

