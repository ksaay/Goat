#include<stdio.h>
#include"SDL/SDL.h"
#include"SDL/SDL_image.h"
#include"SDL/SDL_ttf.h"
#include <time.h>
#include"SDL/SDL_mixer.h"
#include "enigme.h"
int puzzle()
{

int r;
int moves=5;
SDL_Surface *texte = NULL;
SDL_Surface *texte1 = NULL;
TTF_Font *police=NULL;
TTF_Font *police1=NULL;
TTF_Init();
SDL_Color couleurNoire ={255,8,10};
SDL_Color couleur ={255,255,255};
police  = TTF_OpenFont("pacifico.ttf",70);
police1 = TTF_OpenFont("pacifico1.ttf",50);
texte = TTF_RenderText_Blended(police, "GZZZZZ ",couleurNoire);
SDL_Rect gz;
SDL_Rect pmoves;
pmoves.x=400;
pmoves.y=15;
gz.x=300;
gz.y=340;
image e[10];
SDL_Event event;
int i,j,x,y,pos,n=0;
SDL_Surface *screen = NULL;
SDL_Rect pose[10];

load(e);

alea(e);

init(pose);


int taken=0,taken2,pos2,vrf=0;

SDL_Init(SDL_INIT_VIDEO);
screen = SDL_SetVideoMode(790, 700, 32, SDL_HWSURFACE|SDL_DOUBLEBUF);
if(!screen)
{
printf("unable to set 1600 x 400 video : %s\n",SDL_GetError());
return(-1);
}

first(e,screen,pose);
texte1 = TTF_RenderText_Blended(police1, "5 ",couleur);
SDL_BlitSurface(texte1,NULL,screen,&pmoves);
while(moves !=0)
{
vrf=0;

SDL_WaitEvent(&event);
switch(event.type)
{

case SDL_MOUSEBUTTONDOWN:
SDL_GetMouseState(&x,&y);
if(moves>0)
{
if(taken==0)
{
taken=fctpos(x,y);
pos=search(e,taken);
affiche(e,taken,pos,screen,pose);
SDL_BlitSurface(texte1,NULL,screen,&pmoves);
}//taken==0
else
{
taken2=fctpos(x,y);
pos2=search(e,taken2);
affiche2(e,taken,taken2,pos,pos2,screen,pose);
taken=0;
moves--;
switch(moves)
{

case 0:
texte1 = TTF_RenderText_Blended(police1, "0 ",couleur);

break;

case 1: 
texte1 = TTF_RenderText_Blended(police1, "1 ",couleur);

break;

case 2:
texte1 = TTF_RenderText_Blended(police1, "2 ",couleur);

break;

case 3:
texte1 = TTF_RenderText_Blended(police1, "3 ",couleur);

break;

case 4:
texte1 = TTF_RenderText_Blended(police1, "4",couleur);

break;


}
SDL_BlitSurface(texte1,NULL,screen,&pmoves);
}


}
break;
}
for(i=1;i<7;i++)
{
if(e[i].place!=e[i].correct)
vrf=2;
}
if(vrf==0)
{
SDL_BlitSurface(e[0].im,NULL,screen,&pose[0]);
SDL_BlitSurface(texte,NULL,screen,&gz);
SDL_Flip(screen);
SDL_Delay(3000);
return 1;
}



if(moves==0 && vrf!=0)
{
texte = TTF_RenderText_Blended(police1, "Loser  ",couleur);
SDL_BlitSurface(texte,NULL,screen,&gz);
SDL_Flip(screen);
SDL_Delay(3000);
return 0;
}
SDL_Flip(screen);
}



for(i=0;i<7;i++)
{
SDL_FreeSurface(e[i].im);
}

SDL_FreeSurface(screen);
SDL_FreeSurface(texte);
return vrf;


}
void affiche(image e[],int taken,int pos,SDL_Surface *screen,SDL_Rect pose[])
{
int i;
SDL_SetAlpha(e[pos].im, SDL_SRCALPHA, 50);
SDL_BlitSurface(e[7].im,NULL,screen,&pose[7]);
SDL_BlitSurface(e[pos].im,NULL,screen,&pose[taken]);
for(i=1;i<7;i++)
{
if(i!=pos)
SDL_BlitSurface(e[i].im,NULL,screen,&pose[e[i].place]);
}
SDL_BlitSurface(e[pos].im,NULL,screen,&pose[taken]);
}
int search(image e[],int taken)
{
int i;
for(i=1;i<7;i++)
{
if(e[i].place==taken)
return i;
}
}
void affiche2(image e[],int taken,int taken2,int pos,int pos2,SDL_Surface *screen,SDL_Rect pose[])
{
int i,tmp;
SDL_SetAlpha(e[pos].im, 0, 100);
SDL_BlitSurface(e[7].im,NULL,screen,&pose[7]);
for(i=1;i<7;i++)
{
if(i==pos || i==pos2)
{
SDL_BlitSurface(e[pos].im,NULL,screen,&pose[taken2]);
SDL_BlitSurface(e[pos2].im,NULL,screen,&pose[taken]);

}
else 
SDL_BlitSurface(e[i].im,NULL,screen,&pose[e[i].place]);
}
tmp=e[pos].place;
e[pos].place=e[pos2].place;
e[pos2].place=tmp;
}

int fctpos(int x,int y)
{
if(x>=100 && x<=300 && y>=100 && y<350)
{
//SDL_SetAlpha(e[1], SDL_SRCALPHA, 100);

return 1;
}
if(x>=301 && x<=551 && y>=100 && y<350)
{
return 2;
}
if(x>=552 && x<=802 && y>= 100 && y<350)
{
return 3;
}

if(x>=100 && x<=300 && y>=352 && y<600)
{
//SDL_SetAlpha(e[1], SDL_SRCALPHA, 100);
return 4;
}
if(x>=301 && x<=551 && y>=352 && y<600)
{
return 5;
}
if(x>=552 && x<=802 && y>=352 && y<600)
{
return 6;
}


}
void first (image e[],SDL_Surface *screen,SDL_Rect pose[])
{

SDL_BlitSurface(e[7].im,NULL,screen,&pose[7]);
SDL_BlitSurface(e[1].im,NULL,screen,&pose[e[1].place]);
SDL_BlitSurface(e[2].im,NULL,screen,&pose[e[2].place]);
SDL_BlitSurface(e[3].im,NULL,screen,&pose[e[3].place]);
SDL_BlitSurface(e[4].im,NULL,screen,&pose[e[4].place]);
SDL_BlitSurface(e[5].im,NULL,screen,&pose[e[5].place]);
SDL_BlitSurface(e[6].im,NULL,screen,&pose[e[6].place]);
SDL_Flip(screen);
}
void load(image e[])
{
int r;
srand(time(NULL));
e[7].im=IMG_Load("background.png");
r=rand() % 2;
if(r==0)
{
e[0].im=IMG_Load("1.png");
e[1].im=IMG_Load("part1.png");
e[2].im=IMG_Load("part2.png");
e[3].im=IMG_Load("part3.png");
e[4].im=IMG_Load("part4.png");
e[5].im=IMG_Load("part5.png");
e[6].im=IMG_Load("part6.png");
}

else
{
e[0].im=IMG_Load("2.png");
e[1].im=IMG_Load("part11.png");
e[2].im=IMG_Load("part12.png");
e[3].im=IMG_Load("part13.png");
e[4].im=IMG_Load("part14.png");
e[5].im=IMG_Load("part15.png");
e[6].im=IMG_Load("part16.png");
}
}
void init(SDL_Rect pose[])
{
pose[0].x=100;   pose[0].y=100;
pose[1].x=100; pose[1].y=100;
pose[2].x=303; pose[2].y=100;
pose[3].x=505; pose[3].y=100;
pose[4].x=100; pose[4].y=350;
pose[5].x=303; pose[5].y=350;
pose[6].x=505; pose[6].y=350;
pose[7].x=0;   pose[7].y=0;
}
void alea(image e[])
{
int i,j,r;
for(i=1;i<7;i++)
{
e[i].correct=i;
}
for(i=1;i<7;i++)
{
srand(time(NULL));
r=rand() % 6;
r++;
e[i].place=r;
for(j=1;j<i;j++)
{
if (e[j].place==r)
{
i--;
break;
}
}

}

}









