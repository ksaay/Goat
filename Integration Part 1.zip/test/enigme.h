#ifndef FONCTIONS_H_
#define FONCTIONS_H_
typedef struct 
{
SDL_Surface *im;
int correct;
int place;
}image;
void affiche(image e[],int taken,int pos,SDL_Surface *screen,SDL_Rect pose[]);
int search(image e[],int taken);
void affiche2(image e[],int taken,int taken2,int pos,int pos2,SDL_Surface *screen,SDL_Rect pose[]);
int fctpos(int x,int y);
void first (image e[],SDL_Surface *screen,SDL_Rect pose[]);
void load(image e[]);
void init(SDL_Rect pose[]);
void alea(image e[]);
#endif
