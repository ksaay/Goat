#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <SDL/SDL.h>
#include <math.h>
#include <SDL/SDL_image.h>
#include "deplacement.h"

#define width 1600 
#define height 400

#define posXobj1 500 
#define posYobj1 300



void deplacement_enemy(enemi *e,int *a,int *b,int dep1,int dep2)
{
 if((e->posenemi.x!=dep2)&&((*a)==0)&&((*b)==1))
{
  e->posenemi.x+=5;
e->posanime.y=200;
animate_enemi(e);

}
else
{ 
(*a)=1;
(*b)=0;
}

  if((e->posenemi.x!=dep1)&&((*a)==1)&&((*b)==0))
{
  e->posenemi.x-=5;
e->posanime.y=100;
animate_enemi(e);

}
else
{
(*a)=0;
(*b)=1;
}
}

