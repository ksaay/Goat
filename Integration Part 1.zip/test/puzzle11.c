#include<stdio.h>
#include"SDL/SDL.h"
#include"SDL/SDL_image.h"
#include"SDL/SDL_ttf.h"
#include <time.h>
#include"SDL/SDL_mixer.h"
#include "enigme.h"
void affiche(image e[],int taken,int pos,SDL_Surface *screen,SDL_Rect pose[])
{
int i;
SDL_SetAlpha(e[pos].im, SDL_SRCALPHA, 50);
SDL_BlitSurface(e[7].im,NULL,screen,&pose[7]);
SDL_BlitSurface(e[pos].im,NULL,screen,&pose[taken]);
for(i=1;i<7;i++)
{
if(i!=pos)
SDL_BlitSurface(e[i].im,NULL,screen,&pose[e[i].place]);
}
SDL_BlitSurface(e[pos].im,NULL,screen,&pose[taken]);
}
int search(image e[],int taken)
{
int i;
for(i=1;i<7;i++)
{
if(e[i].place==taken)
return i;
}
}
void affiche2(image e[],int taken,int taken2,int pos,int pos2,SDL_Surface *screen,SDL_Rect pose[])
{
int i,tmp;
SDL_SetAlpha(e[pos].im, 0, 100);
SDL_BlitSurface(e[7].im,NULL,screen,&pose[7]);
for(i=1;i<7;i++)
{
if(i==pos || i==pos2)
{
SDL_BlitSurface(e[pos].im,NULL,screen,&pose[taken2]);
SDL_BlitSurface(e[pos2].im,NULL,screen,&pose[taken]);

}
else 
SDL_BlitSurface(e[i].im,NULL,screen,&pose[e[i].place]);
}
tmp=e[pos].place;
e[pos].place=e[pos2].place;
e[pos2].place=tmp;
}

int fctpos(int x,int y)
{
if(x>=100 && x<=300 && y>=100 && y<350)
{
//SDL_SetAlpha(e[1], SDL_SRCALPHA, 100);

return 1;
}
if(x>=301 && x<=551 && y>=100 && y<350)
{
return 2;
}
if(x>=552 && x<=802 && y>= 100 && y<350)
{
return 3;
}

if(x>=100 && x<=300 && y>=352 && y<600)
{
//SDL_SetAlpha(e[1], SDL_SRCALPHA, 100);
return 4;
}
if(x>=301 && x<=551 && y>=352 && y<600)
{
return 5;
}
if(x>=552 && x<=802 && y>=352 && y<600)
{
return 6;
}


}
void first (image e[],SDL_Surface *screen,SDL_Rect pose[])
{

SDL_BlitSurface(e[7].im,NULL,screen,&pose[7]);
SDL_BlitSurface(e[1].im,NULL,screen,&pose[e[1].place]);
SDL_BlitSurface(e[2].im,NULL,screen,&pose[e[2].place]);
SDL_BlitSurface(e[3].im,NULL,screen,&pose[e[3].place]);
SDL_BlitSurface(e[4].im,NULL,screen,&pose[e[4].place]);
SDL_BlitSurface(e[5].im,NULL,screen,&pose[e[5].place]);
SDL_BlitSurface(e[6].im,NULL,screen,&pose[e[6].place]);
SDL_Flip(screen);
}
void load(image e[])
{
int r;
srand(time(NULL));
e[7].im=IMG_Load("background.png");
r=rand() % 2;
if(r==0)
{
e[0].im=IMG_Load("1.png");
e[1].im=IMG_Load("part1.png");
e[2].im=IMG_Load("part2.png");
e[3].im=IMG_Load("part3.png");
e[4].im=IMG_Load("part4.png");
e[5].im=IMG_Load("part5.png");
e[6].im=IMG_Load("part6.png");
}

else
{
e[0].im=IMG_Load("2.png");
e[1].im=IMG_Load("part11.png");
e[2].im=IMG_Load("part12.png");
e[3].im=IMG_Load("part13.png");
e[4].im=IMG_Load("part14.png");
e[5].im=IMG_Load("part15.png");
e[6].im=IMG_Load("part16.png");
}
}
void init(SDL_Rect pose[])
{
pose[0].x=100;   pose[0].y=100;
pose[1].x=100; pose[1].y=100;
pose[2].x=303; pose[2].y=100;
pose[3].x=505; pose[3].y=100;
pose[4].x=100; pose[4].y=350;
pose[5].x=303; pose[5].y=350;
pose[6].x=505; pose[6].y=350;
pose[7].x=0;   pose[7].y=0;
}
void alea(image e[])
{
int i,j,r;
for(i=1;i<7;i++)
{
e[i].correct=i;
}
for(i=1;i<7;i++)
{
srand(time(NULL));
r=rand() % 6;
r++;
e[i].place=r;
for(j=1;j<i;j++)
{
if (e[j].place==r)
{
i--;
break;
}
}

}

}

