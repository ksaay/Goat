#include "vie.h"
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "perso.h"
void init_vie(vie *v) 
{
 (v->position.x)=0;
 (v->position.y)=0;
 (v->val)=5 ;
 (v->image[0])=IMG_Load("8.jpg") ;
 (v->image[1])=IMG_Load("vie1.png") ;
 (v->image[2])=IMG_Load("vie2.png") ;
 (v->image[3])=IMG_Load("vie3.png") ;
 (v->image[4])=IMG_Load("vie4.png") ;
 (v->image[5])=IMG_Load("vie5.png") ;

}
void setup_vie(vie v ,SDL_Surface *ecran)
{
  
  SDL_BlitSurface(v.image[(v.val)],NULL,ecran,&(v.position));
 

}
void lose_vie( vie *v,perso *p)
{
Uint32 end= SDL_GetTicks();
if(end - p-> hit >2000  ||  p->hit == 0)
{
if (v->val>1)
v->val--;
p->hit = end;
}
}
void add_vie(vie *v)
{

v->val=5;
}

void displayvie(vie v ,SDL_Surface *ecran) 
{
  
  SDL_BlitSurface(v.image[(v.val)],NULL,ecran,&(v.position));
  
}


void vie_freevie(vie *v ) 
{
SDL_FreeSurface(v->image[0]);
SDL_FreeSurface(v->image[1]);
SDL_FreeSurface(v->image[2]);
SDL_FreeSurface(v->image[3]);
SDL_FreeSurface(v->image[4]);
SDL_FreeSurface(v->image[5]);
}

			
			
