#ifndef SCORE_H_INCLUDED
#define SCORE_H_INCLUDED 

#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "SDL/SDL_ttf.h"

typedef struct  
{
SDL_Rect position ;  
int val ;
SDL_Surface *texte;
TTF_Font *police;
}score; 

void setup(score *s,SDL_Surface *ecran);
void freescore(score *s);  

#endif
