#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "scrolling.h"


int main()
{
SDL_Surface *screen = NULL ;
Objet map,d ;
int running=1 ,test;

 screen= SDL_SetVideoMode(w, h, 32, SDL_HWSURFACE|SDL_DOUBLEBUF);

  
  initialiser (&map ,&d ) ;
  setup (screen,&map,&d) ;

  SDL_EnableKeyRepeat(10, 10);
  while(running){
deplacement_objet(&map,screen ,&d,&running,&test);
if(test==1)
{
      evenement (screen,&map,&running,&d) ;
}
     }
    free_memory (&map,&d) ;

    

    return EXIT_SUCCESS;
}
