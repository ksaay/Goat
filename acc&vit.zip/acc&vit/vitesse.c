#include <SDL/SDL.h>
#define STAT_SOL 0
#define STAT_AIR 1
#include "vitesse.h"
/**
* @brief To initialize the velocity and acceleration.
* @param  im is the person in the game and x,y are the parameters velocity and xv,xy the acceleratin
*  @return Nothing
*/
void initialisation(image* im)
{
	im->x = 100;
	im->y = 220;
	im->status = STAT_SOL;
	im->vx = 0;
	im->vy = 0;
}
/**
* @brief To initialize the position 
* @param  x,y are parametres of the position,w,h are the height and weight of the screen
*  @return Nothing
*/
void afficher(image* im,SDL_Surface* screen)
{
	SDL_Rect pos;
	pos.x = im->x;
	pos.y = im->y;
	pos.w = 20;
	pos.h = 40;
	SDL_FillRect(screen,&pos,SDL_MapRGB(screen->format,100,50,20));

}
/**
* @brief To study the velocity and the acceleration
* @param  lateralspeed is the velocity 
* @param airlateralspeedfacteur is frottement de l air 
* @param  stop is the stable position 
*  @return Nothing
*/
void Evolue(image* im,Uint8* keys)
{
	float lateralspeed = 0.5;
	float airlateralspeedfacteur = 1.;//frottement de lair
	float acceleration = 15;
	float stop = 1.109;// position stable
	if (im->status == STAT_AIR) //=1
		lateralspeed*= airlateralspeedfacteur;
	if (keys[SDLK_LEFT]) 
		im->vx-=lateralspeed;//pour accelerer en arriere
	if (keys[SDLK_RIGHT])
		im->vx+=lateralspeed;//pour accelerer en avant
	if (im->status == STAT_SOL && !keys[SDLK_LEFT] && !keys[SDLK_RIGHT]) 
		im->vx/=stop; 
	if (im->vx>acceleration) 
		im->vx = acceleration;
	if (im->vx<-acceleration)
		im->vx = -acceleration;
    im->x +=im->vx;
	im->y +=im->vy;
}
