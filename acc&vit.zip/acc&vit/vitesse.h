#ifndef FONCTIONS_H_
#define FONCTIONS_H_
/**
* @struct image
* @brief struct for image
*/
typedef struct
{
	int status; /*!<postion of the person */
	double x,y;/*!<velocity */
	double vx,vy;/*!<acceleration */
} image;
void initialisation(image* im);
void afficher(image* im,SDL_Surface* screen);
void Evolue(image* im,Uint8* keys);

#endif
