#include <SDL/SDL.h>
#define STAT_SOL 0
#define STAT_AIR 1
#include "vitesse.h"
/**
* @file main.c
* @brief velocity and acceleration
* @author Sarra Gara
* @version 0.1
* @date juin 01, 2020
*
* velocity and acceleration
*
*/
int main(int argc,char* argv)
{
	SDL_Surface* screen;
	int numkeys;
	Uint8 * keys;
	image im;
	Uint32 t_prev,dt;
	SDL_Init(SDL_INIT_VIDEO);
	screen=SDL_SetVideoMode(700,300,32,SDL_SWSURFACE|SDL_DOUBLEBUF);
	initialisation(&im);
	do 
	{
		t_prev = SDL_GetTicks();
		SDL_FillRect(screen,NULL,0);
		SDL_PumpEvents();
		keys = SDL_GetKeyState(&numkeys);
		Evolue(&im,keys);
		afficher(&im,screen);
		SDL_Flip(screen);
		dt = SDL_GetTicks() - t_prev;
		if (dt<20)
		SDL_Delay(20-dt);
	} while (!keys[SDLK_ESCAPE]);
	SDL_Quit();
	return 0;
}
